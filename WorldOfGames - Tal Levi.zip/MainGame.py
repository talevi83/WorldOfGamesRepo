from Live import load_game, welcome

name = str(input('What is your name? '))
print(welcome(name))
load_game()